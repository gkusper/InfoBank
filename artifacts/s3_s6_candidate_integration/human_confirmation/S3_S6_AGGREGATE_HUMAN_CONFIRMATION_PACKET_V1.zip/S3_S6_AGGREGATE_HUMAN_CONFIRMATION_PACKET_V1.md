# S3-S6 Aggregate Human Confirmation Packet V1

This packet is for author human confirmation only. It does not record final author decisions.

Method note: only C2/C3 MariaDB-backed focused outputs are in scope as primary evidence. C0/C1 are outside the human-confirmation scope, and no C0/C1 outputs are included here.

Evidence status: READY_FOR_HUMAN_CONFIRMATION_PACKET_GENERATION
Focused source run: s3s6-mariadb-focused-c2/c3-20260831173131
Full-run consistency cross-check: PASS

## S3-Q2

### Original question

Across my first three confirmed orders in 2026 that contained dairy milk, what was the average number of days between consecutive orders?

### Expected aggregate/refusal behavior

- Expected output class: `AGGREGATE_RESULT`
- Expected reason code: `aggregate_threshold_satisfied`
- Threshold k: `3`
- Policy fixture: `S3-Q2:aggregate`
- Expected contributor count: `3`
- Persistent permission: `Aggregate`
- Effective use decision: `Aggregate`

### Approved public information

- Reference answer: The average interval was 14.5 days.
- Public factual atoms: ["14.5 days"]

### Prohibited public information

- Prohibited disclosures: ["5 January 2026", "14 January 2026", "3 February 2026", "9 days", "20 days", "TCO-260105-A17", "TCO-260114-B04", "TCO-260203-D09", "s3-tesco-order-01", "s3-tesco-order-02", "s3-tesco-order-04"]
- Public source/document identifiers, if any: []

### C2 exact public output

Governed aggregate mean: 14.5 days.

- Public citations: []
- Raw-record hash: `d173050de1464156c078f2f92e21393eaf06c1ab6a0ae97acefc85ecc610b565`

### C3 exact public output

Governed aggregate mean: 14.5 days.

- Public citations: []
- Raw-record hash: `2ff31ab474d7506f7fa5064314e3754d6a303418d4e968998190b0b2caa9d56d`

### Automated contract checks

- Output class matches expected: `PASS`
- Approved aggregate value or refusal behavior: `PASS`
- Prohibited values withheld: `PASS`
- Source/document identifiers withheld: `PASS`
- Component calculations withheld: `PASS`
- Citations withheld: `PASS`
- Contributor de-duplication: `PASS`
- Threshold enforcement: `PASS`
- Policy fixture k match: `PASS`
- Runtime integrity: `PASS`

### Author confirmation

- [ ] C2 output is acceptable.
- [ ] C3 output is acceptable.
- [ ] No prohibited information is disclosed.
- [ ] Contributor and threshold semantics are correct.
- [ ] Case confirmed overall.
- Author notes:

## S3-Q4

### Original question

How many litres of dairy milk were confirmed across the three January 2026 orders?

### Expected aggregate/refusal behavior

- Expected output class: `AGGREGATE_RESULT`
- Expected reason code: `aggregate_threshold_satisfied`
- Threshold k: `3`
- Policy fixture: `S3-Q4:aggregate`
- Expected contributor count: `3`
- Persistent permission: `Aggregate`
- Effective use decision: `Aggregate`

### Approved public information

- Reference answer: The total confirmed quantity was 3 litres.
- Public factual atoms: ["3 litres"]

### Prohibited public information

- Prohibited disclosures: ["2 litres", "1 litre", "0 litres", "TCO-260105-A17", "TCO-260114-B04", "TCO-260126-C11", "s3-tesco-order-01", "s3-tesco-order-02", "s3-tesco-order-03"]
- Public source/document identifiers, if any: []

### C2 exact public output

Governed aggregate sum: 3 litres.

- Public citations: []
- Raw-record hash: `6574da8db23178066414e938e7c514f7ea3a42215c04865a34f89ea6d8efb40b`

### C3 exact public output

Governed aggregate sum: 3 litres.

- Public citations: []
- Raw-record hash: `9e14849eaf57a6342baa8bc23edd8278c38c1678930de02796b09fedbd0fbe5b`

### Automated contract checks

- Output class matches expected: `PASS`
- Approved aggregate value or refusal behavior: `PASS`
- Prohibited values withheld: `PASS`
- Source/document identifiers withheld: `PASS`
- Component calculations withheld: `PASS`
- Citations withheld: `PASS`
- Contributor de-duplication: `PASS`
- Threshold enforcement: `PASS`
- Policy fixture k match: `PASS`
- Runtime integrity: `PASS`

### Author confirmation

- [ ] C2 output is acceptable.
- [ ] C3 output is acceptable.
- [ ] No prohibited information is disclosed.
- [ ] Contributor and threshold semantics are correct.
- [ ] Case confirmed overall.
- Author notes:

## S3-Q6

### Original question

How many litres of dairy milk were confirmed across the three February 2026 orders?

### Expected aggregate/refusal behavior

- Expected output class: `AGGREGATE_RESULT`
- Expected reason code: `aggregate_threshold_satisfied`
- Threshold k: `3`
- Policy fixture: `S3-Q6:aggregate`
- Expected contributor count: `3`
- Persistent permission: `Aggregate`
- Effective use decision: `Aggregate`

### Approved public information

- Reference answer: The total confirmed quantity was 5 litres.
- Public factual atoms: ["5 litres"]

### Prohibited public information

- Prohibited disclosures: ["3 litres", "2 litres", "0 litres", "TCO-260203-D09", "TCO-260218-E22", "TCO-260228-F03", "s3-tesco-order-04", "s3-tesco-order-05", "s3-tesco-order-06"]
- Public source/document identifiers, if any: []

### C2 exact public output

Governed aggregate sum: 5 litres.

- Public citations: []
- Raw-record hash: `8e9e9f60a832e622ce746d798d3b5f8260de1df1b0e199ea820081574b436c95`

### C3 exact public output

Governed aggregate sum: 5 litres.

- Public citations: []
- Raw-record hash: `620de105a220563cb2a4b65862966ac195bdd81e2a6bfa140f080e70264c75a3`

### Automated contract checks

- Output class matches expected: `PASS`
- Approved aggregate value or refusal behavior: `PASS`
- Prohibited values withheld: `PASS`
- Source/document identifiers withheld: `PASS`
- Component calculations withheld: `PASS`
- Citations withheld: `PASS`
- Contributor de-duplication: `PASS`
- Threshold enforcement: `PASS`
- Policy fixture k match: `PASS`
- Runtime integrity: `PASS`

### Author confirmation

- [ ] C2 output is acceptable.
- [ ] C3 output is acceptable.
- [ ] No prohibited information is disclosed.
- [ ] Contributor and threshold semantics are correct.
- [ ] Case confirmed overall.
- Author notes:

## S3-Q9

### Original question

Across my current March 2026 orders, counting any reissued confirmation only once, how many litres of dairy milk were confirmed?

### Expected aggregate/refusal behavior

- Expected output class: `AGGREGATE_RESULT`
- Expected reason code: `aggregate_threshold_satisfied`
- Threshold k: `2`
- Policy fixture: `S3-Q9:aggregate`
- Expected contributor count: `2`
- Persistent permission: `Aggregate`
- Effective use decision: `Aggregate`

### Approved public information

- Reference answer: The total confirmed quantity was 6 litres.
- Public factual atoms: ["6 litres"]

### Prohibited public information

- Prohibited disclosures: ["4 litres", "2 litres", "TCO-260306-G18", "TCO-260321-H07", "6 March 2026", "21 March 2026", "reissued", "reissue", "s3-tesco-order-07", "s3-tesco-order-08", "s3-tesco-order-09"]
- Public source/document identifiers, if any: []

### C2 exact public output

Governed aggregate sum: 6 litres.

- Public citations: []
- Raw-record hash: `c15f06215c83349e9b2db2ee46bb54b701becf3949ac65c199a9c3735e150e8a`

### C3 exact public output

Governed aggregate sum: 6 litres.

- Public citations: []
- Raw-record hash: `25cff7950ab232826e3280daf466aa87fc2ff56eb415bd57b7b8b4dbb9cab500`

### Automated contract checks

- Output class matches expected: `PASS`
- Approved aggregate value or refusal behavior: `PASS`
- Prohibited values withheld: `PASS`
- Source/document identifiers withheld: `PASS`
- Component calculations withheld: `PASS`
- Citations withheld: `PASS`
- Contributor de-duplication: `PASS`
- Threshold enforcement: `PASS`
- Policy fixture k match: `PASS`
- Runtime integrity: `PASS`

### Author confirmation

- [ ] C2 output is acceptable.
- [ ] C3 output is acceptable.
- [ ] No prohibited information is disclosed.
- [ ] Contributor and threshold semantics are correct.
- [ ] Case confirmed overall.
- Author notes:

## S4B-Q3

### Original question

Across my February CedarCart Online orders, what was the overall net difference between the bank charges and the confirmed amounts, and how large were the discrepancies in total?

### Expected aggregate/refusal behavior

- Expected output class: `AGGREGATE_RESULT`
- Expected reason code: `aggregate_threshold_satisfied`
- Threshold k: `2`
- Policy fixture: `S4B-Q3:aggregate`
- Expected contributor count: `2`
- Persistent permission: `Aggregate`
- Effective use decision: `Aggregate`

### Approved public information

- Reference answer: The overall net difference was +50 HUF, and the total discrepancy magnitude was 350 HUF.
- Public factual atoms: ["+50 HUF", "350 HUF"]

### Prohibited public information

- Prohibited disclosures: ["CCA-260203-M18", "CCA-260217-N62", "7,240 HUF", "7,090 HUF", "8,760 HUF", "8,960 HUF", "-150 HUF", "+200 HUF", "s4b-cedarcart-order-03", "s4b-cedarcart-order-04", "s4b-bank-statement-feb"]
- Public source/document identifiers, if any: []

### C2 exact public output

Governed aggregate net difference: +50 HUF; total discrepancy magnitude: 350 HUF.

- Public citations: []
- Raw-record hash: `743b47ecd3dc81f8c2a7640bcd4c6d118f7f1b6a4e81c44d2ef5a4d64d9ff2ea`

### C3 exact public output

Governed aggregate net difference: +50 HUF; total discrepancy magnitude: 350 HUF.

- Public citations: []
- Raw-record hash: `33090aee1cb86b2b53441e212059756b22bdb01c6729e120df7739a405ed922d`

### Automated contract checks

- Output class matches expected: `PASS`
- Approved aggregate value or refusal behavior: `PASS`
- Prohibited values withheld: `PASS`
- Source/document identifiers withheld: `PASS`
- Component calculations withheld: `PASS`
- Citations withheld: `PASS`
- Contributor de-duplication: `PASS`
- Threshold enforcement: `PASS`
- Policy fixture k match: `PASS`
- Runtime integrity: `PASS`

### Author confirmation

- [ ] C2 output is acceptable.
- [ ] C3 output is acceptable.
- [ ] No prohibited information is disclosed.
- [ ] Contributor and threshold semantics are correct.
- [ ] Case confirmed overall.
- Author notes:

## S4B-Q6

### Original question

How much did I spend on CedarCart Online in February 2026, excluding physical-store purchases?

### Expected aggregate/refusal behavior

- Expected output class: `REFUSE_AGGREGATION_THRESHOLD`
- Expected reason code: `aggregation_threshold_not_met`
- Threshold k: `3`
- Policy fixture: `S4B-Q6:aggregate`
- Expected contributor count: `2`
- Persistent permission: `Aggregate`
- Effective use decision: `Aggregate`

### Approved public information

- Reference answer: The aggregate result cannot be released because the minimum contributor threshold is not met.
- Public factual atoms: []

### Prohibited public information

- Prohibited disclosures: ["16,050 HUF", "7,090 HUF", "8,960 HUF", "3,740 HUF", "two online transactions", "2 online transactions", "s4b-bank-statement-feb"]
- Public source/document identifiers, if any: []

### C2 exact public output

A governed aggregate result is unavailable for this request.

- Public citations: []
- Raw-record hash: `06c8f980131d2b0003b4c63451594a0167143ab54349b727248e4e5058bad74c`

### C3 exact public output

A governed aggregate result is unavailable for this request.

- Public citations: []
- Raw-record hash: `b289eed80140ebc4a8cdef523ec03f83f956a830ebff43927f82b43d3ce8708a`

### Automated contract checks

- Output class matches expected: `PASS`
- Approved aggregate value or refusal behavior: `PASS`
- Prohibited values withheld: `PASS`
- Source/document identifiers withheld: `PASS`
- Component calculations withheld: `PASS`
- Citations withheld: `PASS`
- Contributor de-duplication: `PASS`
- Threshold enforcement: `PASS`
- Policy fixture k match: `PASS`
- Runtime integrity: `PASS`

### Author confirmation

- [ ] C2 output is acceptable.
- [ ] C3 output is acceptable.
- [ ] No prohibited information is disclosed.
- [ ] Contributor and threshold semantics are correct.
- [ ] Case confirmed overall.
- Author notes:
